/*! mosaicgrid - v0.0.0 - 2013-10-15 */

var subnavState = 0;
var topnavState = 0;
var orientation = "portrait";
var columns = 3;


jQuery(document).ready(function($) {
  init();
});


function init(){
	//console.log("init with jQuery 2");
	footer();
	//loadJSON();
	
	(jQuery)(window).resize(function() {
    checkOrientation();
    footer();
    });
}


function footer(){
    var offset = (jQuery)("footer").offset().top;
    var footerHeight = (jQuery)("footer").height();
    var height = window.innerHeight;
    var diff = height - offset;
    if( offset < height ){
	  (jQuery)("footer").css({'height':diff});
    }else{
	  (jQuery)("footer").css({'height':'auto'});
    }
}


////////////////////////////////////////////////////////////////
////////// NAVIGATION AND MENUS 
////////////////////////////////////////////////////////////////

function subnavSlide(){
  var subnav = document.getElementById("subnav");
  var mainContent = document.getElementById("mainContent");
  var subnavlist = document.getElementById("subnavList");
  var subnavbtn = document.getElementById("subnavBtn");
  if(subnavState == 0) {
	  subnavState = 1;
	  subnav.style.height = "10em";
	  subnav.style.width = "25%";
	  mainContent.style.width = "66.66666%";
  }else{
	  subnavState = 0;  
	  subnav.style.height = "3em";
	  subnav.style.width = "8.33333%";
	  mainContent.style.width = "83.33333%";
  }
  (jQuery)(subnavlist).slideToggle();
}

function topnavSlide(btn){
  var mainnav = document.getElementById("mainnav");
  var tools = document.getElementById("tools");
  var sitemenubtn = document.getElementById("sitemenuBtn");
  var drawer = document.getElementById("drawer");
  if(topnavState == 0) {
	  topnavState = 1;
	  drawer.style.height = "9em";
	  if(btn == 'menu'){
	  	mainnav.style.display = "block";
	  	tools.style.display = "none";
	  }else{
		tools.style.display = "block";
		mainnav.style.display = "none";
	  }
  }else{
	  topnavState = 0;
	  drawer.style.height = "0";
	  tools.style.display = "none";
	  mainnav.style.display = "none";
  }
}


////////////////////////////////////////////////////////////////
////////// ORIENTATION
////////////////////////////////////////////////////////////////

function checkOrientation() {
	var w = (jQuery)(window).width();
	var h = (jQuery)(window).height();
	if (h > w){
		orientation = "portrait";
	}else{
		orientation = "landscape";
	}
	fixIO6PlaceholderBug();
	//console.log(w);
}

/*

var tileState = 0;
var paramsCount = 10;
var iconFolder = "images/glyphs/";
var templateID = 0;
var maxWidth = 0.8333333; ///////// 20 of 24 columns grid system  ///////////////

var tilearr = new Array();
  
function loadJSON() {	
  (jQuery)(document).ready(function(){
	var url = "../mosaicgrid.json";
	var params = {format: 'json'};
	(jQuery).getJSON(url,params,function(json){
      if(json.mosaicgrid){
	    (jQuery).each(json.mosaicgrid, function(i,n){
		  var item = json.mosaicgrid[i];
		  tilearr.push(item);
		});
	  }
	  createTiles();
	});
  });
}

function createTiles() { 
	var tempArr = new Array();
	(jQuery).each(tilearr, function(key, value) {
		(jQuery).each(value, function(index, value) {
			tempArr.push(value);
		});
	});
	for (var i=0;i<=(tempArr.length-1);i++){
	  var title = tempArr[i].title;
      var image = tempArr[i].field_image;
      var path = tempArr[i].path;
      var date = tempArr[i].created;
      var h = tempArr[i].field_imgheight;
      var w = tempArr[i].field_imgwidth;
      var desc = tempArr[i].field_desc;
      var id = i;
      var type = "video";
      //console.log(image);
      drawTile(title,desc,h,w,id,image,type);
	}	
}

function drawTile(label,desc,h,w,id,image,type) {
	var tileContainer = document.createElement('div');
	var tileBtn = document.createElement('div');
	var tileCover = document.createElement('div');
	var tileLabel = document.createElement('div');
	var tileDesc = document.createElement('div');
	var imgOverlay = image;
	var imgType = "";
	
	switch(type){
		case "article":
			imgType = "icon-file";
			break;
		case "photo":
			imgType = "icon-camera";
			break;
		case "video":
			imgType = "icon-camera-2";
			break;
		case "image":
			imgType = "icon-image";
			break;
	}
	
	(jQuery)('#mosaic').append(tileContainer);
	tileContainer.id = id + '_container';
	tileContainer.className = 'msnry_item';
	tileContainer.style.height = h + 'px';
	
	(jQuery)(tileContainer).append(tileDesc);
	tileDesc.id = id + '_desc';
	tileDesc.className = 'tile-desc';
	tileDesc.style.height = h + 'px';
	tileDesc.style.width = '100%';
	(jQuery)(tileDesc).append("<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore</p>");
	
	(jQuery)(tileContainer).append(tileCover);
	tileCover.id = id + '_cover';
	tileCover.className = 'tile-cover tranz_norm';
	tileCover.style.height = h + 'px';
	tileCover.style.width = '100%';
	tileCover.style.backgroundImage = 'url(" ' + imgOverlay + ' ")';
	
	(jQuery)(tileContainer).append(tileLabel);
	tileLabel.id = id + '_label';
	tileLabel.className = 'tile-label';
	(jQuery)(tileLabel).append("<div class='tile_icon_wrapper'><div class='" + imgType + " tile_icon' ></div></div><div class='tile_icon_point'></div><div class='tile_label_txt'>" + label + "</div>");


	////////////////////////////////////////////////////////////////
	////////// SET VARIABLES
	////////////////////////////////////////////////////////////////
	(jQuery)(tileCover).data("tileState",0);

	////////////////////////////////////////////////////////////////
	////////// BUTTON EVENT
	////////////////////////////////////////////////////////////////
	(jQuery)(tileCover).on('mouseover', function(event){
		var cover = id + '_cover';
		tileOpen(cover);
	});
	(jQuery)(tileCover).on('mouseout', function(event){
		var cover = id + '_cover';
		var ref = id + '_desc';
		tileClose(cover,ref);
	});

	////////////////////////////////////////////////////////////////
	////////// CALCULATE HEIGHT
	////////////////////////////////////////////////////////////////
	var tcWidth = document.getElementById(id + '_container').offsetWidth;
	var scale = tcWidth / w;
	var newHH = h * scale;

	(jQuery)(tileContainer).css("height", newHH);
	(jQuery)(tileCover).css("height", newHH);
	(jQuery)(tileDesc).css("height", newHH);
		
	return true;
}
function tileOpen(target) {
	var h = (jQuery)(document.getElementById(target)).parent().height();
	(jQuery)(document.getElementById(target)).data("tileState",1);
	(jQuery)(document.getElementById(target)).css("opacity", "0");
}
function tileClose(target,ref) {
	var h = (jQuery)(document.getElementById(ref)).parent().height();
	(jQuery)(document.getElementById(target)).data("tileState",0);
	(jQuery)(document.getElementById(target)).css("opacity", "1");
}
(jQuery)(window).resize(function() {	
	(jQuery)('.msnry_item').each(function(index){
		var newWW = (jQuery)(this).offsetWidth;
		var scale = newWW / (jQuery)(this).data('w');
		var newHH = (jQuery)(this).data('h') * scale;
		(jQuery)(this).children('.tile-cover').height(newHH);
	});
});
*/


