#!/bin/bash
python -m http.server