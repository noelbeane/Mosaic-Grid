#!/bin/bash
python -m SimpleHTTPServer